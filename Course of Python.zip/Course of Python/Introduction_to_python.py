#                                                   INTRODUZIONE A PYTHON

#POSSIBILI ERRORI CON LA CHIAMATA DI UNA FUNZIONE

# IDENTAZIONE SBAGLIATA
   #print("HELLO WORLD") mi darebbe un errore perchè non rispetta la giusta identazione in questo caso


#CHIAMATA DI UNA FUNZIONE DIVERSA

#pint("HELLO WORLD") mi darebbe errore


#MANCANZA DELLE DOPPIE " " SE  VOGLIO INSERIRE DIRETTAMENTE UNA STRINGA O DI PARENTESI
#print("ciao)
#print("ciao"      entrambi questi codici producono errori


#CASE SENSITIVE
#Python è case-senstive quindi scrivere PRINT("HELLO WORLD") è diverso da scrivere print("Hello world")